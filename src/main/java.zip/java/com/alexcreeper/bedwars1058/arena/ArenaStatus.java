package com.alexcreeper.bedwars1058.arena;

public enum ArenaStatus {
    WAITING, STARTING, PLAYING, ENDING, RESTARTING
}